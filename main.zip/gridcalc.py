from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.ticker import MultipleLocator, FormatStrFormatter
from sys import stdout

from numba import njit
from typing import Callable, Optional, Tuple, Set

from random import random
from libs.effectiveinteractions import effectiveInteractionStar, effectiveInteractionTriangle, square_proj


def update_progress(i, N):
        message = f"Progress: [{'-'*((i*40)//N)+' '*(40 - (i*40)//N)}]  {i}/{N}"
        stdout.write(message)
        stdout.write('\r'*len(message))
        stdout.flush()

it = -1
N = 101

x_min = 0.00001
x_max = 1.5001

y_min = -0.81
y_max = 0.8
depth = 2

# q = 1.9792070717615697+0j
# EEI = (0, 0, 0, 0)
# for j in range(1, 10):
#     EEI = effectiveInteraction(EEI, EEI, q)
#     print(EEI)

@njit(cache = True, fastmath=True)
def checkDFS(q, y_start = 0, depth = 300):
    def f(y):
        return 1 + q / (y - 1)

    stack = [(y_start, depth)]
    while stack:
        y, cur_depth = stack.pop()
        if cur_depth <= 1:
            continue

        if abs(y) > 1 or abs(f(y)) > 1:
            return True

        for j in range(2, cur_depth):
            stack.append((f(y ** j), cur_depth // j))
    return False


def get_wheel(n, q, k = 1):
    def f(y):
        return 1 + q / (y - 1)
    EEI = (0, 0 ,0, f(f(0) ** k))
    EEI_start = EEI
    for _ in range(n):
        EEI = effectiveInteractionStar(EEI, EEI_start, q)
    return EEI


def checkDense(q):

    if checkDFS(q, depth=depth):
            return 1

    for k in range(1,8):
        for n in range(1, 50):
            y = square_proj(get_wheel(n, q, k), get_wheel(n, q, k), q)   # even
            if checkDFS(q, y, depth=depth):
                return k


            y = square_proj(get_wheel(n, q, k), get_wheel(n+1, q, k), q)  # odd
            if checkDFS(q, y, depth=depth):
                return k

    return False

grid = np.zeros((2*N, N))
for x in np.linspace(x_min, x_max, N):
    it += 1
    ity = -1
    for y in np.linspace(-y_max, 0, N+1):
        ity += 1
        q = complex(x, y)

        out = checkDense(q)
    
        grid[ity, it] += out
        if ity == N:
            continue
        grid[-ity, it] += out
        continue

    update_progress(it, N-1)
print("\n")


circle1 = plt.Circle((0.5, 0), 0.5, color='r', fill = False)

circle2 = plt.Circle((2, 0), 1, color='r', fill = False)
fig, ax = plt.subplots()
ax.add_patch(circle1)
ax.add_patch(circle2)
# ax.spines['left'].set_position('center')
ax.spines['bottom'].set_position('center')

# Eliminate upper and right axes
ax.spines['right'].set_color('none')
ax.spines['top'].set_color('none')


ax.xaxis.set_major_locator(MultipleLocator(0.25))
# optional: label format
ax.xaxis.set_major_formatter(FormatStrFormatter('%.1f'))


# Show ticks in the left and lower axes only
ax.xaxis.set_ticks_position('bottom')
ax.yaxis.set_ticks_position('left')
cmap = ListedColormap(["white", "green", "red", "blue"])
ax.imshow(grid, extent=[x_min,x_max, -y_max, y_max], cmap="tab20c") #, cmap=cmap, vmin=0, vmax=3, interpolation="nearest"
plt.savefig("out.png", dpi = 300)
plt.show()
