# Graph_calculator
Program to design, edit and compute graph properties
