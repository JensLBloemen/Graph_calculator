from gui.gui import App

from classes.polynomial import Polynomial as P
from libs.effectiveinteractions import effectiveInteraction as E

from libs.special_graphs import get_vampire
from libs.operations import star

G0 = get_vampire(0)
G = star(G0, G0)
G = star(G, G)
G = star(G, G)
G = star(G, G)
G = star(G, G)
G = star(G, G)
G = star(G, G)
G = star(G, G)


u = G.ids["u"]
t = G.ids["t"]
s = G.ids["s"]

G.delete_vertex(s)
G.add_edge((u, t))

G.name = 'Star'
G.save()


if __name__ == "__main__":
    app = App()
    app.run()

