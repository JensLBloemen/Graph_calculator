"""Given a graph, return the chromatic polynomial"""

def get_chromatic_polynomial(G):
    pass