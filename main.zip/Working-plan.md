## Idea ##
- Graphic user interface to create graphs, edit, save, and do certain operations on them. Possibly with matplotlib and TKinter.
- Calculate the chromatic polynomial and maybe more.
- Calculate roots of the polynomial and display.
- create Pixel pictures.


